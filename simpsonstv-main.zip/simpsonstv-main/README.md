These python scripts are used to make the Desktop Simpsons TV work.

You can find a complete build guide [here](https://withrow.io/simpsons-tv-build-guide)
